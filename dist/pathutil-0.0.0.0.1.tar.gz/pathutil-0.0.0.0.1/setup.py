from setuptools import setup

requirements = ["pydantic"]

setup(
    name="pathutil",
    version="0.0.0.0.1",
    author="Marcuth",
    author_email="marcuth2006@gmail.com",
    packages=["pathutil"],
    install_requires=requirements
)